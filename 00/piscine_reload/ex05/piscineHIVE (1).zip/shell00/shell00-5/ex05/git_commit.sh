#!/bin/sh
git log --pretty=format:"%H" -n5 && echo
